﻿/// <reference path="sys\jquery-2.2.4.js"/>
/// <reference path="sys\jquery.mobile-1.4.6.js"/>
/// <reference path="sys\MicrosoftAjax.min.js" />
/// <reference path="daf\daf.js"/>
/// <reference path="daf\touch.js"/>
/// <reference path="daf\touch-charts.js"/>
